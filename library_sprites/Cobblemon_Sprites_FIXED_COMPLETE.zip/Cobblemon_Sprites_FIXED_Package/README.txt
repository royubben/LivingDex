COBBLEMON SPRITES - FIXED COMPLETE REBUILD

1. Zet deze drie bestanden in een NIEUWE lege map:
   DOWNLOAD_ALL_COBBLEMON_SPRITES_FIXED.py
   DOWNLOAD_ALL_COBBLEMON_SPRITES_FIXED.bat
   LivingDex_Cobblemon_Final_Data.json

2. Dubbelklik op DOWNLOAD_ALL_COBBLEMON_SPRITES_FIXED.bat

3. De output komt in:
   Cobblemon_Sprites_REBUILT_FIXED\sprites

Belangrijk:
- Normale/base Pokemon: eerst echte Cobblemon Wiki model-render proberen.
- De Cobblemon Wiki gebruikt voor de normale modelbestanden '(model)' met kleine m.
- Speciale vormen met een expliciete Wiki-URL in de JSON gebruiken exact die bron.
- Regionale hoofdvormen gebruiken PokeAPI 2D volgens de afgesproken regel.
- HTML/error responses worden geweigerd; alleen echte PNG's worden opgeslagen.
- De oude V4-map wordt nooit aangepast.
