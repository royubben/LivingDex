#!/usr/bin/env python3
from pathlib import Path
import json,re,shutil,time,urllib.parse,urllib.request
from collections import Counter

BASE=Path(__file__).resolve().parent
DATA=BASE/'LivingDex_Cobblemon_Final_Data.json'
OUT=BASE/'Cobblemon_Sprites_REBUILT_FIXED'
SPR=OUT/'sprites'
REPORT=OUT/'SPRITE_REPORT.txt'
MANIFEST=OUT/'SPRITE_MANIFEST.json'
API='https://wiki.cobblemon.com/api.php'
UA='Cobblemon-LivingDex-Fixed/3.0'
EXPECTED=1282

REGIONAL={'alolan','galarian','hisuian','paldean'}

def entries(d):
    out=[]
    for p in d['main']: out += p['entries']
    for p in d['pages'].values(): out += p['entries']
    return out

def filename(e):
    s=e['name'].replace('—',' ').strip()
    s=re.sub(r'\s+','_',s)
    s=re.sub(r'[<>:"/\\|?*]','',s)
    return f"{int(e['dex']):04d}_{s}.png"

def get(url,accept='*/*'):
    req=urllib.request.Request(url,headers={'User-Agent':UA,'Accept':accept})
    with urllib.request.urlopen(req,timeout=35) as r:
        return r.read(),r.headers.get('Content-Type',''),r.geturl()

def png(url):
    try:
        b,ct,final=get(url,'image/png,image/*;q=.9,*/*;q=.1')
        if b[:8]==b'\x89PNG\r\n\x1a\n' and len(b)>=100:
            return b,final
    except Exception:
        pass
    return None,None

def api(params):
    try:
        u=API+'?'+urllib.parse.urlencode(params)
        b,_,_=get(u,'application/json')
        return json.loads(b.decode('utf-8'))
    except Exception:
        return None

def exact_file_candidates(name):
    base=name.strip()
    # The Wiki's actual base model files use lowercase (model), not (Model).
    vals=[f'{base} (model).png',f'{base} (Model).png']
    # Common Wiki naming variants.
    vals += [
        f'{base.replace(" F", "-F")} (model).png',
        f'{base.replace(" M", "-M")} (model).png',
        f'{base.replace(" F", "_F")} (model).png',
        f'{base.replace(" M", "_M")} (model).png',
    ]
    seen=[]
    for x in vals:
        if x not in seen: seen.append(x)
    return seen

def wiki_file_url(fn):
    return 'https://wiki.cobblemon.com/wiki/Special:Redirect/file/'+urllib.parse.quote(fn,safe='')

def wiki_file_api(fn):
    d=api({'action':'query','format':'json','formatversion':'2','titles':'File:'+fn,'prop':'imageinfo','iiprop':'url|mime'})
    try:
        p=d['query']['pages'][0]
        if p.get('missing'): return None
        ii=(p.get('imageinfo') or [])[0]
        if ii.get('mime')=='image/png': return ii.get('url')
    except Exception: pass
    return None

def wiki_search(name):
    # Search only File namespace and rank exact model-like filenames highly.
    q=f'{name} model'
    d=api({'action':'query','format':'json','formatversion':'2','generator':'search','gsrsearch':q,'gsrnamespace':6,'gsrlimit':20,'prop':'imageinfo','iiprop':'url|mime'})
    cand=[]
    for p in (d or {}).get('query',{}).get('pages',[]):
        title=p.get('title','').removeprefix('File:')
        ii=(p.get('imageinfo') or [None])[0] or {}
        u=ii.get('url')
        if not u or ii.get('mime')!='image/png': continue
        norm=lambda x: re.sub(r'[^a-z0-9]','',x.lower())
        score=0
        n=norm(name); t=norm(title)
        if n==t.removesuffix('modelpng'): score+=100
        if n in t: score+=40
        if 'model' in t: score+=20
        if title.lower().endswith('(model).png'): score+=20
        cand.append((score,title,u))
    cand.sort(reverse=True)
    return cand

def resolve_base(e):
    # 1 exact filenames, lowercase model first
    for fn in exact_file_candidates(e['name']):
        u=wiki_file_url(fn); b,final=png(u)
        if b: return b,final,'Cobblemon Wiki exact model'
        u2=wiki_file_api(fn)
        if u2:
            b,final=png(u2)
            if b: return b,final,'Cobblemon Wiki exact model (API)'
    # 2 MediaWiki file search
    for _,title,u in wiki_search(e['name']):
        b,final=png(u)
        if b: return b,final,f'Cobblemon Wiki file search: {title}'
    return None,None,None

def resolve_json(e):
    u=e.get('sprite','')
    if not u: return None,None,None,'no sprite URL'
    b,final=png(u)
    if b: return b,final,('Cobblemon Wiki explicit source' if 'wiki.cobblemon.com' in u else 'PokeAPI 2D'),'ok'
    if 'wiki.cobblemon.com' in u:
        fn=urllib.parse.unquote(urllib.parse.urlparse(u).path.rsplit('/',1)[-1])
        u2=wiki_file_api(fn)
        if u2:
            b,final=png(u2)
            if b: return b,final,'Cobblemon Wiki explicit source (API)','ok'
    return None,None,None,'download failed'

def main():
    if not DATA.exists(): raise SystemExit('ERROR: LivingDex_Cobblemon_Final_Data.json ontbreekt naast dit script.')
    d=json.loads(DATA.read_text(encoding='utf-8')); es=entries(d)
    if len(es)!=EXPECTED: raise SystemExit(f'ERROR: {len(es)} entries gevonden; verwacht {EXPECTED}. Niets uitgevoerd.')
    if len({e['id'] for e in es})!=EXPECTED: raise SystemExit('ERROR: dubbele IDs in JSON. Niets uitgevoerd.')
    names=[filename(e) for e in es]
    if len(set(names))!=EXPECTED: raise SystemExit('ERROR: dubbele output-bestandsnamen. Niets uitgevoerd.')
    if OUT.exists(): shutil.rmtree(OUT)
    SPR.mkdir(parents=True)
    stats=Counter(); manifest=[]; report=['COBBLEMON SPRITES - FIXED COMPLETE REBUILD','='*70]
    for i,e in enumerate(es,1):
        print(f'[{i:04d}/{EXPECTED}] {e["name"]}')
        b=u=src=err=None
        note=(e.get('note') or '').lower(); form=(e.get('form') or '').lower()
        explicit='wiki.cobblemon.com' in (e.get('sprite') or '')
        regional=(form in REGIONAL)
        if explicit:
            b,u,src,err=resolve_json(e); stats['WIKI_EXPLICIT' if b else 'FAILED']+=1
        elif regional:
            b,u,src,err=resolve_json(e); stats['POKEAPI_REGIONAL' if b else 'FAILED']+=1
        elif not form:
            b,u,src=resolve_base(e)
            if b: stats['WIKI_BASE']+=1
            else:
                b,u,src,err=resolve_json(e)
                if b: stats['POKEAPI_BASE_FALLBACK']+=1
                else: stats['FAILED']+=1
        else:
            b,u,src,err=resolve_json(e)
            stats['JSON_SPECIAL' if b else 'FAILED']+=1
        fn=filename(e); p=SPR/fn
        if b:
            p.write_bytes(b)
            manifest.append({'id':e['id'],'dex':e['dex'],'name':e['name'],'form':e.get('form',''),'source':src,'source_url':u,'file':fn})
            report.append(f'OK | {e["id"]} | {e["name"]} | {src} | {fn}')
        else:
            report.append(f'FAILED | {e["id"]} | {e["name"]} | {err or "unknown"}')
        time.sleep(.06)
    MANIFEST.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    files=list(SPR.glob('*.png')); invalid=[]
    for p in files:
        try:
            if p.read_bytes()[:8]!=b'\x89PNG\r\n\x1a\n': invalid.append(p.name)
        except: invalid.append(p.name)
    report += ['', '='*70,'SUMMARY','='*70]
    report += [f'{k}: {v}' for k,v in sorted(stats.items())]
    report += [f'Files written: {len(files)}',f'Expected: {EXPECTED}',f'Invalid PNG: {len(invalid)}',f'Missing: {EXPECTED-len(manifest)}']
    REPORT.write_text('\n'.join(report),encoding='utf-8')
    print('\n'+'='*70); print('KLAAR'); print('='*70)
    print(f'Wiki base renders:      {stats["WIKI_BASE"]}')
    print(f'Wiki explicit forms:    {stats["WIKI_EXPLICIT"]}')
    print(f'PokeAPI regional:       {stats["POKEAPI_REGIONAL"]}')
    print(f'PokeAPI base fallback:  {stats["POKEAPI_BASE_FALLBACK"]}')
    print(f'Failures:               {stats["FAILED"]}')
    print(f'PNG files:              {len(files)}/{EXPECTED}')
    print(f'Report:                 {REPORT}')
    input('\nDruk op Enter om af te sluiten...')
if __name__=='__main__': main()
