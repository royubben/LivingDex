@echo off
chcp 65001 >nul
title Cobblemon Sprites - Fixed Complete Rebuild
python "%~dp0DOWNLOAD_ALL_COBBLEMON_SPRITES_FIXED.py"
pause
